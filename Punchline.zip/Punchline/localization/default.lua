return {
	["misc"] = {
		["dictionary"] = {
			['punch_RelicBooster1'] = 'Relic Pack',
			['punch_RelicBooster2'] = 'Relic Pack',
			['punch_RelicBooster3'] = 'Relic Pack',
			['punch_RelicBooster4'] = 'Relic Pack',
			['punch_RelicBooster5'] = 'Jumbo Relic Pack',
			['punch_RelicBooster6'] = 'Jumbo Pack',
			['punch_RelicBooster7'] = 'Mega Relic Pack',
			['punch_RelicBooster8'] = 'Mega Relic Pack',
        },
		['labels'] = {
			punch_Fridge = 'Fridge Magnet',
		}
    }
}